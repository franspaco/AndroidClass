package com.franspaco.tareacms2;

public class BackEnd {
    public static final String imgUrl = "http://ubiquitous.csf.itesm.mx/~pddm-1019512/img/";
    public static final String baseUrl = "http://ubiquitous.csf.itesm.mx/~pddm-1019512/coches/v1";
    public static final String brandsUrl = baseUrl + "/brands";
    public static final String qryId = baseUrl + "?id=";
    public static final String qryBrand = baseUrl + "?brand=";
    public static final String qryBrandId = baseUrl + "?brandid=";
    public static final String qryModel = baseUrl + "?model=";
}
