package com.franspaco.tareacms2;

import java.util.ArrayList;

public class Car {
    public int brandId;
    public int id;
    public String brand;
    public String model;
    public ArrayList<String> imgs;
}
